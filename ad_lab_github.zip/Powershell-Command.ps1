# Script: Bulk create AD users in specific OU
# Author: Anthony
# Description: Reads users from a CSV and creates them in a specific OU.

Import-Module ActiveDirectory

$OU = "OU=NewYork,DC=Antdomain,DC=com"
$Users = Import-Csv -Path "C:\Scripts\NewUsers.csv"

foreach ($User in $Users) {
    $Password = ConvertTo-SecureString "ChangeMe123!" -AsPlainText -Force
    New-ADUser -Name "$($User.FirstName) $($User.LastName)" `
               -SamAccountName $User.SamAccountName `
               -UserPrincipalName $User.UPN `
               -AccountPassword $Password `
               -Enabled $true `
               -Path $OU `
               -City $User.City

    Write-Output "User $($User.FirstName) $($User.LastName) created in OU=$OU."
}
