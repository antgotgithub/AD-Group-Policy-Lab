# Script: Create a new AD User
# Author: Anthony
# Description: Prompts for details to create a new Active Directory user.

Import-Module ActiveDirectory

$FirstName = Read-Host "Enter First Name"
$LastName = Read-Host "Enter Last Name"
$SamAccountName = Read-Host "Enter SamAccountName"
$UPN = Read-Host "Enter UserPrincipalName (UPN)"

$Password = ConvertTo-SecureString "ChangeMe123!" -AsPlainText -Force

New-ADUser -Name "$FirstName $LastName" `
           -SamAccountName $SamAccountName `
           -UserPrincipalName $UPN `
           -AccountPassword $Password `
           -Enabled $true

Write-Output "User $FirstName $LastName created successfully."
