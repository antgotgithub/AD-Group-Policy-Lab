# Script: Bulk create AD users from CSV
# Author: Anthony
# Description: Reads users from a CSV file and creates them in AD.

Import-Module ActiveDirectory

$Users = Import-Csv -Path "C:\Scripts\NewUsers.csv"

foreach ($User in $Users) {
    $Password = ConvertTo-SecureString "ChangeMe123!" -AsPlainText -Force
    New-ADUser -Name "$($User.FirstName) $($User.LastName)" `
               -SamAccountName $User.SamAccountName `
               -UserPrincipalName $User.UPN `
               -AccountPassword $Password `
               -Enabled $true `
               -City $User.City

    Write-Output "User $($User.FirstName) $($User.LastName) created."
}
