# Active Directory Lab Scripts

This repository contains PowerShell scripts and CSV files used for managing an Active Directory (AD) lab environment.

## Contents
- **NewADUser.ps1** – Script to create a new AD user from input.
- **UserCSV Read.ps1** – Bulk creation of AD users from a CSV file.
- **NewUsers.csv** – Example CSV with user data for bulk import.
- **Powershell-Command.ps1** – Example script for bulk user creation in a specific OU.

## Notes
- Example passwords are placeholders. Always update them before running in production.
- Domain used: `Antdomain.com` (for lab/demo purposes).
- These scripts are for educational purposes.
